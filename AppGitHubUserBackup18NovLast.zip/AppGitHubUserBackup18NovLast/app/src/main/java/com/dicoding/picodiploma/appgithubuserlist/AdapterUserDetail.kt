package com.dicoding.picodiploma.appgithubuserlist

class AdapterUserDetail {

}